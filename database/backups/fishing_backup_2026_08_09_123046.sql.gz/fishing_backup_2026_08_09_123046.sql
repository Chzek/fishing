-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: mysql    Database: fishing_test
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anglers`
--

DROP TABLE IF EXISTS `anglers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `anglers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middleName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user.jpg',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `anglers_firstname_middlename_lastname_unique` (`firstName`,`middleName`,`lastName`),
  KEY `anglers_user_id_foreign` (`user_id`),
  CONSTRAINT `anglers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anglers`
--

LOCK TABLES `anglers` WRITE;
/*!40000 ALTER TABLE `anglers` DISABLE KEYS */;
/*!40000 ALTER TABLE `anglers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crews`
--

DROP TABLE IF EXISTS `crews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crews` (
  `expeditions_id` int unsigned NOT NULL,
  `anglers_id` int unsigned NOT NULL,
  `joined` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `crews_expeditions_id_foreign` (`expeditions_id`),
  KEY `crews_anglers_id_foreign` (`anglers_id`),
  CONSTRAINT `crews_anglers_id_foreign` FOREIGN KEY (`anglers_id`) REFERENCES `anglers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `crews_expeditions_id_foreign` FOREIGN KEY (`expeditions_id`) REFERENCES `expeditions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crews`
--

LOCK TABLES `crews` WRITE;
/*!40000 ALTER TABLE `crews` DISABLE KEYS */;
/*!40000 ALTER TABLE `crews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expeditions`
--

DROP TABLE IF EXISTS `expeditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expeditions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `start` date NOT NULL,
  `finish` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expeditions`
--

LOCK TABLES `expeditions` WRITE;
/*!40000 ALTER TABLE `expeditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `expeditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fish_breeds`
--

DROP TABLE IF EXISTS `fish_breeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fish_breeds` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `fish_families_id` int unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fish_breeds_name_unique` (`name`),
  KEY `fish_breeds_fish_families_id_foreign` (`fish_families_id`),
  CONSTRAINT `fish_breeds_fish_families_id_foreign` FOREIGN KEY (`fish_families_id`) REFERENCES `fish_families` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fish_breeds`
--

LOCK TABLES `fish_breeds` WRITE;
/*!40000 ALTER TABLE `fish_breeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `fish_breeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fish_families`
--

DROP TABLE IF EXISTS `fish_families`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fish_families` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fish_families_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fish_families`
--

LOCK TABLES `fish_families` WRITE;
/*!40000 ALTER TABLE `fish_families` DISABLE KEYS */;
/*!40000 ALTER TABLE `fish_families` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fishing_rules`
--

DROP TABLE IF EXISTS `fishing_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fishing_rules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `fishing_zone_id` bigint unsigned DEFAULT NULL,
  `lake_id` int unsigned DEFAULT NULL,
  `fish_breed_id` int unsigned DEFAULT NULL,
  `species_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_aggregate` tinyint(1) NOT NULL DEFAULT '0',
  `aggregate_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `season` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sport_limit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conservation_limit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size_restriction` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fishing_rules_fishing_zone_id_foreign` (`fishing_zone_id`),
  KEY `fishing_rules_lake_id_foreign` (`lake_id`),
  KEY `fishing_rules_fish_breed_id_foreign` (`fish_breed_id`),
  CONSTRAINT `fishing_rules_fish_breed_id_foreign` FOREIGN KEY (`fish_breed_id`) REFERENCES `fish_breeds` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fishing_rules_fishing_zone_id_foreign` FOREIGN KEY (`fishing_zone_id`) REFERENCES `fishing_zones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fishing_rules_lake_id_foreign` FOREIGN KEY (`lake_id`) REFERENCES `lakes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fishing_rules`
--

LOCK TABLES `fishing_rules` WRITE;
/*!40000 ALTER TABLE `fishing_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `fishing_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fishing_zones`
--

DROP TABLE IF EXISTS `fishing_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fishing_zones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province_state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ontario',
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Canada',
  `description` text COLLATE utf8mb4_unicode_ci,
  `regulations_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bounds` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fishing_zones_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fishing_zones`
--

LOCK TABLES `fishing_zones` WRITE;
/*!40000 ALTER TABLE `fishing_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `fishing_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lake_daily_weather`
--

DROP TABLE IF EXISTS `lake_daily_weather`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lake_daily_weather` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `lakes_id` int unsigned NOT NULL,
  `date` date NOT NULL,
  `air_temp_max` decimal(5,2) DEFAULT NULL,
  `air_temp_min` decimal(5,2) DEFAULT NULL,
  `air_temp_mean` decimal(5,2) DEFAULT NULL,
  `barometric_pressure` decimal(6,2) DEFAULT NULL,
  `wind_speed_max` decimal(5,2) DEFAULT NULL,
  `wind_direction_dominant` int DEFAULT NULL,
  `weather_condition` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weather_code` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lake_daily_weather_lakes_id_date_unique` (`lakes_id`,`date`),
  CONSTRAINT `lake_daily_weather_lakes_id_foreign` FOREIGN KEY (`lakes_id`) REFERENCES `lakes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lake_daily_weather`
--

LOCK TABLES `lake_daily_weather` WRITE;
/*!40000 ALTER TABLE `lake_daily_weather` DISABLE KEYS */;
/*!40000 ALTER TABLE `lake_daily_weather` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lakes`
--

DROP TABLE IF EXISTS `lakes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lakes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  `structure` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_depth` int unsigned DEFAULT NULL,
  `fishing_zone_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lakes_name_unique` (`name`),
  KEY `lakes_fishing_zone_id_foreign` (`fishing_zone_id`),
  CONSTRAINT `lakes_fishing_zone_id_foreign` FOREIGN KEY (`fishing_zone_id`) REFERENCES `fishing_zones` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lakes`
--

LOCK TABLES `lakes` WRITE;
/*!40000 ALTER TABLE `lakes` DISABLE KEYS */;
/*!40000 ALTER TABLE `lakes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lures`
--

DROP TABLE IF EXISTS `lures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lures` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lures_name_color_size_unique` (`name`,`color`,`size`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lures`
--

LOCK TABLES `lures` WRITE;
/*!40000 ALTER TABLE `lures` DISABLE KEYS */;
/*!40000 ALTER TABLE `lures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_09_08_171440_create_anglers_table',1),(4,'2018_09_08_203959_create_lakes_table',1),(5,'2018_09_09_103018_create_fish_families_table',1),(6,'2018_09_09_103425_create_fish_breeds_table',1),(7,'2018_09_09_230825_add_image_field_to_fish_breeds_table',1),(8,'2018_09_10_203420_create_lures_table',1),(9,'2018_09_11_231326_create_records_table',1),(10,'2018_09_16_140216_create_expeditions_table',1),(11,'2018_09_16_141928_create_crews_table',1),(12,'2018_09_16_142156_create_posts_table',1),(13,'2018_09_22_142153_update_record_allow_null_weight',1),(14,'2019_10_09_221959_add_birthdate_to_anglers_table',1),(15,'2020_06_24_065735_create_notifications_table',1),(16,'2021_04_24_170459_add_avatar_to_anglers_table',1),(17,'2022_09_12_120238_add_angler_to_posts',1),(18,'2023_06_07_000001_create_pulse_tables',1),(19,'2026_08_01_000001_add_foreign_keys_and_indexes',1),(20,'2026_08_01_000002_add_soft_deletes_to_core_tables',1),(21,'2026_08_01_000003_add_client_id_to_records_table',1),(22,'2026_08_02_000001_fix_record_weight_length_precision',1),(23,'2026_08_02_000002_create_lake_daily_weather_table',1),(24,'2026_08_02_000003_add_structure_and_depth_to_lakes_table',1),(25,'2026_08_08_120000_add_latitude_longitude_to_records_table',1),(26,'2026_08_08_130000_add_soft_deletes_to_lures_table',1),(27,'2026_08_08_140000_grant_admin_to_gmroczek_user',1),(28,'2026_08_09_000001_create_fishing_zones_table',1),(29,'2026_08_09_000002_add_fishing_zone_id_to_lakes_table',1),(30,'2026_08_09_000003_create_fishing_rules_table',1),(31,'2026_08_09_000004_add_aggregate_fields_to_fishing_rules_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `expeditions_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `anglers_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_expeditions_id_foreign` (`expeditions_id`),
  KEY `posts_anglers_id_foreign` (`anglers_id`),
  CONSTRAINT `posts_anglers_id_foreign` FOREIGN KEY (`anglers_id`) REFERENCES `anglers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `posts_expeditions_id_foreign` FOREIGN KEY (`expeditions_id`) REFERENCES `expeditions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pulse_aggregates`
--

DROP TABLE IF EXISTS `pulse_aggregates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pulse_aggregates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `bucket` int unsigned NOT NULL,
  `period` mediumint unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_hash` binary(16) GENERATED ALWAYS AS (unhex(md5(`key`))) VIRTUAL,
  `aggregate` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(20,2) NOT NULL,
  `count` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pulse_aggregates_bucket_period_type_aggregate_key_hash_unique` (`bucket`,`period`,`type`,`aggregate`,`key_hash`),
  KEY `pulse_aggregates_period_bucket_index` (`period`,`bucket`),
  KEY `pulse_aggregates_type_index` (`type`),
  KEY `pulse_aggregates_period_type_aggregate_bucket_index` (`period`,`type`,`aggregate`,`bucket`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pulse_aggregates`
--

LOCK TABLES `pulse_aggregates` WRITE;
/*!40000 ALTER TABLE `pulse_aggregates` DISABLE KEYS */;
/*!40000 ALTER TABLE `pulse_aggregates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pulse_entries`
--

DROP TABLE IF EXISTS `pulse_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pulse_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` int unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_hash` binary(16) GENERATED ALWAYS AS (unhex(md5(`key`))) VIRTUAL,
  `value` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pulse_entries_timestamp_index` (`timestamp`),
  KEY `pulse_entries_type_index` (`type`),
  KEY `pulse_entries_key_hash_index` (`key_hash`),
  KEY `pulse_entries_timestamp_type_key_hash_value_index` (`timestamp`,`type`,`key_hash`,`value`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pulse_entries`
--

LOCK TABLES `pulse_entries` WRITE;
/*!40000 ALTER TABLE `pulse_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `pulse_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pulse_values`
--

DROP TABLE IF EXISTS `pulse_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pulse_values` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` int unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_hash` binary(16) GENERATED ALWAYS AS (unhex(md5(`key`))) VIRTUAL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pulse_values_type_key_hash_unique` (`type`,`key_hash`),
  KEY `pulse_values_timestamp_index` (`timestamp`),
  KEY `pulse_values_type_index` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pulse_values`
--

LOCK TABLES `pulse_values` WRITE;
/*!40000 ALTER TABLE `pulse_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `pulse_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `records`
--

DROP TABLE IF EXISTS `records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `records` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `client_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anglers_id` int unsigned NOT NULL,
  `lakes_id` int unsigned NOT NULL,
  `fish_breeds_id` int unsigned NOT NULL,
  `lures_id` int unsigned DEFAULT NULL,
  `weight` decimal(6,2) DEFAULT NULL,
  `length` decimal(5,2) NOT NULL,
  `temperature` float DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `released` tinyint(1) NOT NULL DEFAULT '0',
  `caught` date NOT NULL,
  `trip_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `records_client_id_unique` (`client_id`),
  KEY `records_anglers_id_foreign` (`anglers_id`),
  KEY `records_lakes_id_foreign` (`lakes_id`),
  KEY `records_fish_breeds_id_foreign` (`fish_breeds_id`),
  KEY `records_lures_id_foreign` (`lures_id`),
  KEY `records_caught_index` (`caught`),
  CONSTRAINT `records_anglers_id_foreign` FOREIGN KEY (`anglers_id`) REFERENCES `anglers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `records_fish_breeds_id_foreign` FOREIGN KEY (`fish_breeds_id`) REFERENCES `fish_breeds` (`id`) ON DELETE CASCADE,
  CONSTRAINT `records_lakes_id_foreign` FOREIGN KEY (`lakes_id`) REFERENCES `lakes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `records_lures_id_foreign` FOREIGN KEY (`lures_id`) REFERENCES `lures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `records`
--

LOCK TABLES `records` WRITE;
/*!40000 ALTER TABLE `records` DISABLE KEYS */;
/*!40000 ALTER TABLE `records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-09 12:30:46
